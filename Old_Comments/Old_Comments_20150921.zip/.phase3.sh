#!/bin/bash

# Actually go pick up the variables from phase1 if they are not already set
[ "" == "${PITD}" ] && . ${1}
# From the first script we have inherited these values (all absolute paths)
# PITD		PostInstall Temp Dir
# FTPDIR	The 'pub' subdirectory on the FTP server
# MPOINT	Where the PostInstall ISO is/was mounted
# CDDEVICE	What device we found the PostInstall ISO in
# NIC1NAME  Name of the first configured Ethernet NIC
# NIC2NAME  Name of the second configured Ethernet NIC

[ "" == "${PITD}" ] && echo "DANGER: Error in collection of phase1 variables, contact developer/mentor." && exit 1

LOG="${PITD}/phase3.log"
echo "Phase two complete." | tee -a "${LOG}"
echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-" | tee -a "${LOG}"

if [ ${DONORMALCONFIG} -eq 1 ]; then   # Not indenting all of this, search for "DONORMALCONFIG" to find the end of the if block
echo "Setting up general stuff." | tee -a "${LOG}"

############################################################
# /etc/kickstart-release
############################################################
# Set in the first file, postinstall.sh
#echo "Red Hat Lab server1 kickstart 0.9.5" >/etc/kickstart-release
cat /etc/kickstart-release >>/etc/issue

############################################################
# Random Number Generator daemon
############################################################
# See https://access.redhat.com/articles/1314933 , but in short I ran into
# times when the system could basically stall for no good reason and found
# the entropy pool was running low.  This is a simple way to give it a
# kick and keep processes from stalling.  The KB recommends some edits
# to the service's unit file but they don't appear to be required.
systemctl enable rngd.service &>>"${LOG}"
systemctl start rngd.service  &>>"${LOG}"

############################################################
# routes for testing
############################################################
echo "   Internal lab routes" | tee -a "${LOG}"
for i in `seq -w 1 ${NUMOFWS}`
do
cat >>/etc/sysconfig/network-scripts/route-Internal <<EOF
172.26.$i.0/24 via 172.26.0.2$i dev ${NIC2NAME}
EOF
done
#/etc/init.d/network restart

############################################################
# web server httpd
############################################################
echo "   httpd / Apache" | tee -a "${LOG}"
cd /var/www/html
ln -s ${FTPDIR}
systemctl enable httpd.service &>>"${LOG}"
systemctl start httpd.service &>>"${LOG}"

############################################################
# ftp server vsftpd
############################################################
echo "   vsftpd" | tee -a "${LOG}"
systemctl enable vsftpd.service &>>"${LOG}"
systemctl start vsftpd.service &>>"${LOG}"

############################################################
# dhcp server
############################################################
echo "   dhcpd" | tee -a "${LOG}"
sed -i.bak -e s/DHCPDARGS=/DHCPDARGS=${NIC2NAME}/ /etc/sysconfig/dhcpd
cat >/etc/dhcp/dhcpd.conf <<EOF
authoritative;
default-lease-time 14400;
max-lease-time 14400;
lease-file-name "/var/lib/dhcpd/dhcpd.leases";
ddns-update-style none;
option domain-name "example.com";
option subnet-mask 255.255.255.0;

allow booting;
allow bootp;
option magic      code 208 = string;
option configfile code 209 = text;
option pathprefix code 210 = text;
option reboottime code 211 = unsigned integer 32;
class "pxeclients" {
   match if substring(option vendor-class-identifier, 0, 9) = "PXEClient";
   next-server 172.26.0.1;
   filename "pxelinux.0";
   # Reboot timeout after TFTP failure in seconds, 0 ~= forever
   option reboottime 30;
   # Magic was required for PXELINUX prior to v3.55
   option magic f1:00:74:7e;
   if exists dhcp-parameter-request-list {
     option dhcp-parameter-request-list = concat(option dhcp-parameter-request-list, d0, d1, d2, d3);
   }
}

subnet 172.26.0.0 netmask 255.255.255.0 {
        option domain-name-servers 172.26.0.1;
        option routers 172.26.0.1;
        option broadcast-address 172.26.0.255;
        range 172.26.0.101 172.26.0.151;
}

host station1 {
        option host-name "station1";
        fixed-address 172.26.0.201;
        hardware ethernet 00:50:56:bb:75:ab;
}
host station2 {
        option host-name "station2";
        fixed-address 172.26.0.202;
        hardware ethernet 00:50:56:bb:55:3d;
}
EOF
systemctl enable dhcpd.service &>>"${LOG}"
systemctl start dhcpd.service &>>"${LOG}"

############################################################
# DNS server bind
############################################################
echo "   named / DNS" | tee -a "${LOG}"
# We no longer use a subdirectory for chroot'd bind config
# files.  See https://access.redhat.com/articles/770133 for details.
# 2015-03-23 - For the moment I am NOT using chroot'd bind anyway.  --Daniel_Johnson1
cat >/etc/named.conf <<EOF
options {
        directory "/var/named";
# password flag - change the forwarder DNS servers
        forwarders { 8.8.8.8; 8.8.4.4; };
        listen-on { 127.0.0.1; 172.26.0/24; };
};
zone "example.com" IN {
        type master;
        file "db.example.com";
        allow-update { none; };
};
zone "0.26.172.in-addr.arpa" IN {
        type master;
        file "db.0.26.172.in-addr.arpa";
        allow-update { none; };
};
zone "4.2.3.0.5.1.0.2.1.1.e.d.7.0.d.f.ip6.arpa" IN {
		type master;
		file "db.4.2.3.0.5.1.0.2.1.1.e.d.7.0.d.f.ip6.arpa";
		allow-update {none; };
};
EOF
cat >/var/named/db.0.26.172.in-addr.arpa <<EOF
\$TTL 86400
@       IN      SOA     server1.example.com.    root.server1.example.com.       (
                                                20080915        ; Serial
                                                28800                   ; Refresh
                                                14400                   ; Retry
                                                3600000                 ; Expire
                                                86400 )                 ; Minimum


                        IN NS   server1.example.com.

1                       IN PTR  server1.example.com.
\$GENERATE 1-9  20\$    IN PTR  station\$.example.com.
\$GENERATE 10-${NUMOFWS}  2\$   IN PTR  station\$.example.com.

\$GENERATE 1-9   10\$     IN PTR  dhcp\$.example.com.
\$GENERATE 10-${NUMOFWS} 1\$      IN PTR  dhcp\$.example.com.
EOF
cat >/var/named/db.4.2.3.0.5.1.0.2.1.1.e.d.7.0.d.f.ip6.arpa <<EOF
;
; fd07:de11:2015:324::/64
;
; Zone file built with the IPv6 Reverse DNS zone builder
; http://rdns6.com/
;
\$TTL 1h ; Default TTL
\$ORIGIN 4.2.3.0.5.1.0.2.1.1.e.d.7.0.d.f.ip6.arpa.
@   IN   SOA   server1.example.com.   root.server1.example.com.   (
    2015032401 ; serial
    1h         ; slave refresh interval
    15m        ; slave retry interval
    1w         ; slave copy expire time
    1h         ; NXDOMAIN cache time
    )

;
; domain name servers
;
@ IN NS server1.example.com.


; IPv6 PTR entries
1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.4.2.3.0.5.1.0.2.1.1.e.d.7.0.d.f.ip6.arpa.    IN    PTR    server1.example.com.

EOF
cat >/var/named/db.example.com <<EOF
\$TTL 86400
@       1D IN SOA       server1.example.com.       root.server1.example.com.    (
                                20080916                ; serial (yyyymmdd)
                                3H                      ; refresh
                                15M                     ; retry
                                1W                      ; expiry
                                1D )                    ; minimum

                IN      NS      server1.example.com.

; station1      IN A    172.26.0.101
server1         IN A    172.26.0.1
server1         IN AAAA FD07:DE11:2015:0324::1
\$GENERATE 1-9 station\$  IN A    172.26.0.20\$
\$GENERATE 10-${NUMOFWS} station\$  IN A    172.26.0.2\$

\$GENERATE 1-9 dhcp\$    IN A    172.26.0.10\$
\$GENERATE 10-${NUMOFWS} dhcp\$  IN A    172.26.0.1\$
EOF
for i in `seq 1 9`; do
cat >/var/named/db.station$i.com <<EOF
\$TTL 86400
@       1D IN SOA       server1.example.com.       root.server1.example.com.    (
                                20080921                ; serial (yyyymmdd)
                                3H                      ; refresh
                                15M                     ; retry
                                1W                      ; expiry
                                1D )                    ; minimum

                IN      NS      station$i.com.
                IN      NS      station$i.example.com.
                IN      NS      server1.example.com.

                IN MX 10    station$i.com
                IN A    172.26.0.20$i
www             IN A    172.26.0.20$i
ns              IN A    172.26.0.20$i
EOF
done

for i in `seq 10 ${NUMOFWS}`; do
cat >/var/named/db.station$i.com <<EOF
\$TTL 86400
@       1D IN SOA       server1.example.com.       root.server1.example.com.    (
                                20080921                ; serial (yyyymmdd)
                                3H                      ; refresh
                                15M                     ; retry
                                1W                      ; expiry
                                1D )                    ; minimum

                IN      NS      station$i.com.
                IN      NS      station$i.example.com.
                IN      NS      server1.example.com.

                IN A    172.26.0.2$i
                IN MX 10 172.26.0.2$i
www             IN A    172.26.0.2$i
ns              IN A    172.26.0.2$i
EOF
done


for i in `seq 1 9`; do
cat >>/etc/named.conf <<EOF
zone "station$i.com" IN {
        type master;
        file "db.station$i.com";
        allow-update { none; };
        allow-transfer { 172.26.0.20$i; };
};
EOF
done

for i in `seq 10 ${NUMOFWS}`; do
cat >>/etc/named.conf <<EOF
zone "station$i.com" IN {
        type master;
        file "db.station$i.com";
        allow-update { none; };
        allow-transfer { 172.26.0.2$i; };
};
EOF
done

systemctl enable named.service &>>"${LOG}"
systemctl start named.service &>>"${LOG}"

############################################################
# tftp for pxe installing of stations
############################################################
echo "   tftpd" | tee -a "${LOG}"
# Enable the service within xinetd
#sed -r 's/(disable\s*=\s*)(yes)/\1no/' -i.bak /etc/xinetd.d/tftp
# ..as above but also configure it to have verbose logging (every tftp request gets logged this way)
sed -r -i.bak -e 's/(disable\s*=\s*)(yes)/\1no/'  -e 's/(server_args\s*)(=\s*-s)/\1= -v -s/' /etc/xinetd.d/tftp
# Make the xinetd service notice our changes
echo "Reloading xinetd.service"  &>>"${LOG}"
systemctl reload xinetd.service  &>>"${LOG}"
#####
# I had an issue where xinetd stopped and did not restart for some reason.
# Minor issue, since it works on reboot anyway.
sleep 1
echo "Checking xinetd.service and starting if still needed"  &>>"${LOG}"
( systemctl is-active xinetd.service || systemctl start xinetd.service ) &>>"${LOG}"

mkdir -p /var/lib/tftpboot/pxelinux.cfg &>>"${LOG}"

# 0.17.11
#export repo_file=`find /var/ftp/pub/ -type f -name "media.repo"|head -n1`
#export distro_name=`grep name= $repo_file | cut -d= -f2`
#export short_name=`echo $distro_name|sed -e 's/Red Hat Enterprise Linux /rhel/'`
#echo $repo_file
#echo $distro_name
#echo $short_name

cat >/var/lib/tftpboot/pxelinux.cfg/default <<EOF
display f1.msg
prompt 0
timeout 0
default rhel-7.0

label quit
  localboot 0

EOF
# Very clever here, outputs the appropriate code sequence to make the 
# screen clear when the test file is displayed.  Or is supposed to,
# not working any more??
echo `clear` >/var/lib/tftpboot/f1.msg
cat >>/var/lib/tftpboot/f1.msg <<EOF
pxe boot menu

type this : to do this
quit      : boot the local hard drive
EOF

for full_path in `find ${FTPDIR} -name pxeboot -type d` ; do
  # Note that this loop is checking for the name of the subdirectory under 'pub'.
  # It is expected that each RHEL version will be in a different subdir of 'pub' directly
  # rather than something like 'pub/RHEL/7.0', 'pub/RHEL/7.1', etc.
  #echo $full_path
  # comp_name = extract the 5th field, divider /
  export comp_name=`echo $full_path|cut -d'/' -f5`
  mkdir -p /var/lib/tftpboot/$comp_name
  cp $full_path/* /var/lib/tftpboot/$comp_name/ &>>"${LOG}"
  
  cat >>/var/lib/tftpboot/pxelinux.cfg/default <<EOF
label $comp_name
  kernel $comp_name/vmlinuz
  append initrd=${comp_name}/initrd.img root=live:http://server1.example.com/pub/${comp_name}/dvd/LiveOS/squashfs.img repo=http://server1.example.com/pub/${comp_name}/dvd/ noipv6 ks=http://server1.example.com/pub/station_ks.cfg
EOF

  cat >>/var/lib/tftpboot/f1.msg <<EOF
$comp_name   : install $comp_name
EOF
done
# 0.17.11 add a trailing slash to clarify we are copying to a directory
cp -a /usr/share/syslinux/pxelinux.0 /var/lib/tftpboot/ &>>"${LOG}"
restorecon -R /var/lib/tftpboot/

############################################################
# ntp server - Disabled in favor of the RHEL 7.0-default chronyd
############################################################
#fixme
#echo "   ntpd" | tee -a "${LOG}"
#cat >/etc/ntp.conf <<EOF
#restrict default kod nomodify notrap nopeer noquery
#restrict 127.0.0.1
#restrict -6 ::1
#restrict 172.26.0.0 mask 255.255.0.0 nomodify notrap
#restrict 127.127.1.0
#server 127.127.1.0
#fudge   127.127.1.0 stratum 3
#driftfile /var/lib/ntp/drift
#keys /etc/ntp/keys
##server ntp.us.dell.com
#restrict ntp.us.dell.com mask 255.255.255.255 nomodify notrap noquery
#EOF
##/etc/init.d/ntpd restart
#chkconfig ntpd on
##ntpdate ntp.us.dell.com

############################################################
# NIS server - Deprecated, commented out 2015-07-01
############################################################
#echo "   NIS / YP" | tee -a "${LOG}"
#mkdir /home/server1
#cat >>/etc/exports <<EOF
#/home/server1         *(rw,sync)
#EOF
#exportfs -a
#cat >>/etc/sysconfig/network <<EOF
#NISDOMAIN="CLASS-NIS"
#YPSERV_ARGS=" -p 808"
##YPXFRD_ARGS=" -p 809"
#EOF
#cat >>/etc/yp.conf <<EOF
#ypserver 127.0.0.1
#EOF
##/etc/init.d/portmap start
##/etc/init.d/ypserv start
#systemctl enable ypserv.service &>>"${LOG}"
#systemctl start ypserv.service &>>"${LOG}"
#
#
### By simply getting input from /dev/null we skip the CTRL+D prompt, and Y
### appears to be the default.
## The path is different on 32-bit systems and 64-bit systems.
## "32-bit?  Everything is 64-bit now!"  Does it hurt to check?
#[ -x /usr/lib/yp/ypinit ] && /usr/lib/yp/ypinit -m </dev/null  &>>"${LOG}"
#[ -x /usr/lib64/yp/ypinit ] && /usr/lib64/yp/ypinit -m </dev/null  &>>"${LOG}"

############################################################
# making some users
############################################################
echo "   Lab Users" | tee -a "${LOG}"
# password flag
# Using UID 5,000 to keep it out of the normal user-range
## Disabled 2015-07-01 as we are planning to use guest01 in its place
##useradd -g users -g 100 -u 5000 ldapuser &>>"${LOG}"
##echo "password" | passwd --stdin ldapuser &>>"${LOG}"

# Adding the group here, admittedly 'early'.  We set up Samba
# access for the "studentX" logins, not "guestX".
groupadd smbuser &>>"${LOG}"

# This directory is also referenced later
mkdir /home/server1 &>>"${LOG}"
# Was 50, dropped to 11, then made into a variable NUMOFWS
for i in `seq -w 1 ${NUMOFWS}`; do
  # password flag
  # This block is not creating a group per user.  For now we don't care.
  useradd -g users -u 20$i -d /home/server1/guest$i guest$i  &>>"${LOG}"
  echo "password" | passwd --stdin guest$i  &>>"${LOG}"
done

#cd /var/yp
sed -e s/MINUID=500/MINUID=1000/ -i /var/yp/Makefile
sed -e s/MINGID=500/MINGID=1000/ -i /var/yp/Makefile
#and you don't need to make again unless you add users
#make -C /var/yp

############################################################
# Create Certificate Authority CA
############################################################
echo "   Local CA" | tee -a "${LOG}"
# clean-up
# rm /etc/pki/CA/private/cakey.pem /etc/pki/CA/cacert.pem /var/ftp/pub/materials/cacert.pem
# password flag
(umask 077;openssl genrsa -passout pass:cacertpass -out /etc/pki/CA/private/cakey.pem -des3 2048)  &>>"${LOG}"
# password flag
openssl req -new -x509 -passin pass:cacertpass -key /etc/pki/CA/private/cakey.pem -days 3650 >/etc/pki/CA/cacert.pem <<EOF  2>>"${LOG}"
US
Texas
Round Rock
Dell

server1.example.com
root@server1.example.com
EOF

mkdir -p ${FTPDIR}/materials
rm -f ${FTPDIR}/materials/cacert.pem
cp /etc/pki/CA/cacert.pem ${FTPDIR}/materials/cacert.pem

touch /etc/pki/CA/index.txt
echo "01" > /etc/pki/CA/serial
touch /etc/pki/CA/cacert.srl
echo "01" > /etc/pki/CA/cacert.srl

# was "/etc/openldap/cacerts/" in all three references on the next two lines
cp /etc/pki/CA/cacert.pem /etc/openldap/certs/
ln -s /etc/openldap/certs/cacert.pem /etc/openldap/certs/`openssl x509 -hash -noout -in /etc/openldap/certs/cacert.pem`.0 &>>"${LOG}"
# http://server1.example.com/pub/materials/cacert.pem

############################################################
# Create ldap server certs
############################################################
echo "   LDAP" | tee -a "${LOG}"
# to test tls
# ldapsearch -H 'ldap://server1.example.com' -D 'uid=guest01,ou=People,dc=example,dc=com' -x -W -b "dc=example,dc=com" -ZZ -d1

openssl req -new -x509 -nodes -out /etc/openldap/certs/cert.pem -keyout /etc/openldap/certs/priv.pem -days 365 <<EOF &>>"${LOG}"
US
Texas
Round Rock
Dell
Red Hat In A Box lab
server1.example.com
root@server1.example.com
EOF

# Not needed any longer?  2015-07-01
#cd /etc/pki/tls/certs
##(umask 77 ; /usr/bin/openssl genrsa -passout pass:asdf -out /etc/pki/tls/certs/ldap.key -aes128 2048)
##openssl rsa -passin pass:asdf -in /etc/pki/tls/certs/ldap.key -out /etc/pki/tls/certs/ldap.key
#(umask 77 ; /usr/bin/openssl genrsa -passout pass:asdf -out /etc/pki/tls/certs/ldap.key 2048)  &>>"${LOG}"
##  DEBUG: The next command used to read "...req $(UTF8) -new...".  I see no command or environment variable by that name.
#(umask 77 ; /usr/bin/openssl req -new -key /etc/pki/tls/certs/ldap.key -out /etc/pki/tls/certs/ldap.csr <<EOF  &>>"${LOG}"
#US
#Texas
#Round Rock
#Dell
#
#server1.example.com
#root@server1.example.com
#
#
#EOF
#)
#


# Not needed any longer?  2015-07-01
## password flag
#openssl ca -passin pass:cacertpass -in /etc/pki/tls/certs/ldap.csr -out /etc/pki/tls/certs/ldap.crt <<EOF  &>>"${LOG}"
#y
#y
#EOF
#
#chown ldap:ldap /etc/pki/tls/certs/ldap.*  &>>"${LOG}"

# Error:
# failed to update database
# TXT_DB error number 2
#
# solution: 
# look in /etc/pki/CA/
# openssl ca -revoke /etc/pki/CA/newcerts/02.pem
#
# to test tls
# ldapsearch -H 'ldap://server1.example.com' -D 'uid=guest01,ou=People,dc=example,dc=com' -x -W -b "dc=example,dc=com" -ZZ -d1

# ERROR:
# ldap_start_tls: Connect error (-11)
#         additional info: TLS error -8172:Unknown code ___f 20
#
# you used the BAD COMMAND:
# openssl x509 -req -passin pass:cacertpass -in /etc/pki/tls/certs/ldap.csr \
# -out /etc/pki/tls/certs/ldap.crt -CA /etc/pki/CA/cacert.pem -CAkey /etc/pki/CA/private/cakey.pem
#
# instead of the GOOD COMMAND:
# openssl ca -passin pass:cacertpass -in /etc/pki/tls/certs/ldap.csr -out /etc/pki/tls/certs/ldap.crt

# how to verify the certificate
# openssl verify -purpose sslserver -CAfile /etc/pki/CA/cacert.pem /etc/pki/tls/certs/ldap.crt
# how to make the hash link for /etc/openldap/cacerts
# ln -s server.pem `openssl x509 -hash -noout -in server.pem`.0
# cp /etc/pki/tls/cacert.pem /etc/openldap/cacerts/
# ln -s /etc/openldap/cacerts/cacert.pem /etc/openldap/cacerts/`openssl x509 -hash -noout -in /etc/openldap/cacerts/cacert.pem`.0

############################################################
# ldap server
############################################################
if [ ${DOLDAPCONFIG} -eq 1 ]; then  # Not indenting the block, search for "#End of DOLDAPCONFIG"

echo "Starting the new LDAP stuff" &>>"${LOG}"

# Certificate generated earlier
#openssl req -new -x509 -nodes -out /etc/openldap/certs/cert.pem -keyout /etc/openldap/certs/priv.pem -days 365 &>>"${LOG}"
chown ldap:ldap /etc/openldap/certs/* &>>"${LOG}"
chmod 600 /etc/openldap/certs/priv.pem &>>"${LOG}"
(cp /usr/share/openldap-servers/DB_CONFIG.example /var/lib/ldap/DB_CONFIG; slaptest) &>>"${LOG}"
chown ldap:ldap /var/lib/ldap/* &>>"${LOG}"
systemctl enable slapd.service &>>"${LOG}"
systemctl start slapd.service &>>"${LOG}"
ldapadd -Y EXTERNAL -H ldapi:/// -D "cn=config" -f /etc/openldap/schema/cosine.ldif &>>"${LOG}"
ldapadd -Y EXTERNAL -H ldapi:/// -D "cn=config" -f /etc/openldap/schema/nis.ldif &>>"${LOG}"
cp /etc/openldap/certs/cert.pem /var/www/html/pub/materials/ &>>"${LOG}"

# To change the olcRootPW entry below, run this command and copy the output.
#    slappasswd -s redhat -n > /etc/openldap/passwd 
# For now the hash below is from 'redhat'.

# Be careful with this redirect or it will dump the output to the log instead of the LDIF file
cat <<EOF >/etc/openldap/changes.ldif 2>>"${LOG}"
dn: olcDatabase={2}hdb,cn=config
changetype: modify
replace: olcSuffix
olcSuffix: dc=example,dc=com

dn: olcDatabase={2}hdb,cn=config
changetype: modify
replace: olcRootDN
olcRootDN: cn=Manager,dc=example,dc=com

dn: olcDatabase={2}hdb,cn=config
changetype: modify
replace: olcRootPW
olcRootPW: {SSHA}5ya72uj/eu56gNRYC1l/tW2XJBsO7/RJ

dn: cn=config
changetype: modify
replace: olcTLSCertificateFile
olcTLSCertificateFile: /etc/openldap/certs/cert.pem

dn: cn=config
changetype: modify
replace: olcTLSCertificateKeyFile
olcTLSCertificateKeyFile: /etc/openldap/certs/priv.pem

dn: cn=config
changetype: modify
replace: olcLogLevel
olcLogLevel: -1

dn: olcDatabase={1}monitor,cn=config
changetype: modify
replace: olcAccess
olcAccess: {0}to * by dn.base="gidNumber=0+uidNumber=0,cn=peercred,cn=external,cn=auth" read by dn.base="cn=Manager,dc=example,dc=com" read by * none
EOF

ldapmodify -Y EXTERNAL -H ldapi:/// -f /etc/openldap/changes.ldif &>>"${LOG}"

# Be careful with this redirect or it will dump the output to the log instead of the LDIF file
cat <<EOF >/etc/openldap/base.ldif 2>>"${LOG}"
dn: dc=example,dc=com
dc: example
objectClass: top
objectClass: domain

dn: ou=People,dc=example,dc=com
ou: People
objectClass: top
objectClass: organizationalUnit

dn: ou=Group,dc=example,dc=com
ou: Group
objectClass: top
objectClass: organizationalUnit
EOF

ldapadd -x -w redhat -D cn=Manager,dc=example,dc=com -f /etc/openldap/base.ldif &>>"${LOG}"

pushd /usr/share/migrationtools &>>"${LOG}"
#Edit the migrate_common.ph file and replace in the following lines:
# $DEFAULT_MAIL_DOMAIN = "example.com";
# $DEFAULT_BASE = "dc=example,dc=com";
sed -e s/padl/example/ -e s/ou=Group/ou=Groups/ migrate_common.ph -i.bak  &>>"${LOG}"

# Note, this should get all of guest01 through guest##.
grep "guest" /etc/passwd > passwd 2>>"${LOG}"
./migrate_passwd.pl passwd users.ldif &>>"${LOG}"
ldapadd -x -w redhat -D cn=Manager,dc=example,dc=com -f users.ldif &>>"${LOG}"
grep "guest" /etc/group > group 2>>"${LOG}"
./migrate_group.pl group groups.ldif &>>"${LOG}"
ldapadd -x -w redhat -D cn=Manager,dc=example,dc=com -f groups.ldif &>>"${LOG}"
popd &>>"${LOG}"

echo "Testing the new LDAP stuff" &>>"${LOG}"
ldapsearch -x cn=guest01 -b dc=example,dc=com &>>"${LOG}"

echo "Finished the new LDAP stuff" &>>"${LOG}"

## OLD CRAP BELOW HERE
#
#cat >>/etc/openldap/slapd.d/cn=config.ldif <<EOF
#olcTLSCACertificateFile: /etc/pki/CA/cacert.pem
#olcTLSCertificateFile: /etc/pki/tls/certs/ldap.crt
#olcTLSCertificateKeyFile: /etc/pki/tls/certs/ldap.key
#olcTLSCRLCheck: none
#olcTLSVerifyClient: never
#EOF
#
## 5-9-2012
##/etc/pki/CA/cacert.pem is not readable by "ldap"           [WARNING]
##/etc/pki/tls/certs/ldap.crt is not readable by "ldap"      [WARNING]
#
#
#cd /usr/share/migrationtools
#sed -e s/padl/example/ -e s/ou=Group/ou=Groups/ migrate_common.ph -i.bak
#awk -F: '{if (($3 > 999) && ($3 != 65535)) print $0}' /etc/passwd >/tmp/passwd
#awk -F: '{if (($3 > 999) && ($3 != 65535)) print $0}' /etc/group >/tmp/group
#./migrate_base.pl >/root/ldap.ldif
#./migrate_passwd.pl /tmp/passwd >>/root/ldap.ldif
#./migrate_group.pl /tmp/group >>/root/ldap.ldif
#grep dc=my-domain /etc/openldap/slapd.d/* -Rl|xargs sed -i -e s/dc=my-domain/dc=example/ &>>"${LOG}"
## password flag
## use the command "slappasswd" to generate the hash
## the following command makes a hash with the password "password" and places it in the config file
## password flag
#
#cp /usr/share/openldap-servers/DB_CONFIG.example /var/lib/ldap/DB_CONFIG
#chown ldap. /var/lib/ldap/DB_CONFIG
#
#export hdbldif=$(find /etc/openldap/slapd.d/ -name "*hdb.ldif")
#if [ -f "${hdbldif}" ]; then
#  echo "olcRootPW: $(slappasswd -ns password)" >>"${hdbldif}"
#else
#  echo "ERROR: Did not find an LDIF file to store the olcRootPW in." | tee -a "${LOG}"
#fi
#
#
#cat >/root/.ldaprc <<EOF
#BINDDN cn=Manager,dc=example,dc=com
#EOF
#systemctl enable slapd.service &>>"${LOG}"
#systemctl start slapd.service  &>>"${LOG}"
#sleep 3
## password flag
#ldapadd -c -f /root/ldap.ldif -H ldap://localhost -w password -x -D "cn=Manager,dc=example,dc=com" &>>"${LOG}"
else #DOLDAPCONFIG
  echo "LDAP configuration skipped by command argument." | tee -a "${LOG}"
fi #End of DOLDAPCONFIG main block

############################################################
# kerberos
############################################################
if [ ${DOKERBEROSCONFIG} -eq 1 ]; then # Not indenting the block, search for "#End of DOKERBEROSCONFIG"
echo "   Kerberos" | tee -a "${LOG}"

# Uncomment the 'master_key_type' line, allowing for leading whitespace before the #
#sed -i  '/master_key_type/s/^ *#//' /var/kerberos/krb5kdc/kdc.conf &>>"${LOG}"
# Aahh, screw it.  There's a better way.

cat <<EOF | patch -b -d /var/kerberos/krb5kdc &>>"${LOG}"
--- kdc.conf_orig       2014-03-11 19:22:53.000000000 +0000
+++ kdc.conf    2015-07-01 02:03:50.212004811 +0000
@@ -5,5 +5,6 @@
 [realms]
  EXAMPLE.COM = {
-  #master_key_type = aes256-cts
+  master_key_type = aes256-cts
+  default_principal_flags = +preauth
   acl_file = /var/kerberos/krb5kdc/kadm5.acl
   dict_file = /usr/share/dict/words
EOF

[ ! -f /etc/krb5.conf_orig ] && cp -a /etc/krb5.conf /etc/krb5.conf_orig
# This was originally done with a patch, but it's as large as the end-result
# file and couldn't be directly edited.  Back to nuke-and-replace.
cat <<EOF >/etc/krb5.conf 2>>"${LOG}"
[logging]
 default = FILE:/var/log/krb5libs.log
 kdc = FILE:/var/log/krb5kdc.log
 admin_server = FILE:/var/log/kadmind.log

[libdefaults]
 dns_lookup_realm = false
 ticket_lifetime = 24h
 renew_lifetime = 7d
 forwardable = true
 rdns = false
 default_realm = EXAMPLE.COM
 default_ccache_name = KEYRING:persistent:%{uid}

 default_realm = EXAMPLE.COM
 dns_lookup_kdc = false
[realms]
 EXAMPLE.COM = {
  kdc = server1.example.com
  admin_server = server1.example.com
 }

[domain_realm]
 .example.com = EXAMPLE.COM
 example.com = EXAMPLE.COM
EOF


# /var/kerberos/krb5kdc/kadm5.acl ...we're already just using example.com

# This step can appear to hang if the entropy pool is low.  This is what
# led me to install and enable rngd.
echo "Kernel entropy pool value before: `cat /proc/sys/kernel/random/entropy_avail`" &>>"${LOG}"
echo -e "redhat\nredhat" | kdb5_util create -s -r EXAMPLE.COM &>>"${LOG}"
echo "Kernel entropy pool value after: `cat /proc/sys/kernel/random/entropy_avail`" &>>"${LOG}"

systemctl enable krb5kdc &>>"${LOG}"
systemctl enable kadmin &>>"${LOG}"
systemctl start krb5kdc &>>"${LOG}"
systemctl start kadmin &>>"${LOG}"

# The user 'guest01' here was originally 'ldapuser'
cat EOF | kadmin.local  &>>"${LOG}"
addprinc root/admin
redhat
redhat

addprinc -randkey host/server1.example.com
addprinc -randkey nfs/server1.example.com
addprinc -randkey host/station1.example.com
addprinc -randkey nfs/station1.example.com

# These have to run after all of the addprinc's.
ktadd host/server1.example.com
ktadd host/station1.example.com
ktadd nfs/server1.exameple.com
ktadd nfs/station1.example.com

ktadd -k /var/kerberos/krb5kdc/kadm5.keytab kadmin/admin kadmin/changepw
quit
EOF

cp /etc/krb5.keytab ${FTPDIR}/materials/krb5.keytab
chmod a+r ${FTPDIR}/materials/krb5.keytab &>>"${LOG}"

# REMOVE THESE
# Holding, Aaron may want these in the kadmin.local block above
#addprinc -randkey nfs/station1.example.com
#ktadd nfs/station1.example.com
#addprinc -randkey nfs/station2.example.com
#ktadd nfs/station2.example.com

for NUM in `seq -w -s " " 1 ${NUMOFWS}`; do
  echo -e "redhat\nredhat" | kadmin.local -q "addprinc guest${NUM}" &>>"${LOG}"
done

cat <<EOF | patch -b -d /etc/ssh &>>"${LOG}"
--- ssh_config_orig     2014-03-19 20:50:07.000000000 +0000
+++ ssh_config  2015-07-01 03:16:39.423873305 +0000
@@ -51,4 +51,5 @@
 Host *
        GSSAPIAuthentication yes
+       GSSAPIDelegateCredentials yes
 # If this option is set to yes then remote X11 clients will have full access
 # to the original X11 display. As virtually no X11 client supports the untrusted
EOF

# Be careful with the log redirection here, or it will write the text to
# the log instead of the XML file.
cat <<EOF >/etc/firewalld/services/kerberos.xml 2>>"${LOG}"
<?xml version="1.0" encoding="utf-8"?>
<service>
  <short>Kerberos</short>
  <description>Kerberos network authentication protocol server</description>
  <port protocol="tcp" port="88"/>
  <port protocol="udp" port="88"/>
  <port protocol="tcp" port="749"/>
</service>
EOF

authconfig --enablekrb5 --update &>>"${LOG}"

cat <<EOF | patch -b -d /etc &>>"${LOG}"
--- idmapd.conf_orig	2014-01-26 12:33:44.000000000 +0000
+++ idmapd.conf	2015-08-13 20:33:47.151534977 +0000
@@ -3,5 +3,5 @@
 # The following should be set to the local NFSv4 domain name
 # The default is the host's DNS domain name.
-#Domain = local.domain.edu
+Domain = example.com
 
 # The following is a comma-separated list of Kerberos realm
@@ -18,6 +18,6 @@
 [Mapping]
 
-#Nobody-User = nobody
-#Nobody-Group = nobody
+Nobody-User = nfsnobody
+Nobody-Group = nfsnobody
 
 [Translation]
@@ -29,5 +29,5 @@
 # New methods may be defined and inserted in the list.
 # The default is "nsswitch".
-#Method = nsswitch
+Method = nsswitch
 
 # Optional.  This is a comma-separated, ordered list of
EOF


cp /etc/krb5.conf ${FTPDIR}/materials/ &>>"${LOG}"
cp /etc/idmapd.conf ${FTPDIR}/materials/ &>>"${LOG}"


##### OLD STUFF BELOW HERE
##mv /etc/krb5.conf{,.backup} &>>"${LOG}"
### step 2
##cat >/etc/krb5.conf <<EOF
##[logging]
## default = FILE:/var/log/krb5libs.log
## kdc = FILE:/var/log/krb5kdc.log
## admin_server = FILE:/var/log/kadmind.log
##
##[libdefaults]
## default_realm = EXAMPLE.COM
## dns_lookup_realm = false
## dns_lookup_kdc = false
## ticket_lifetime = 24h
## renew_lifetime = 7d
## forwardable = true
##
##[realms]
### EXAMPLE.COM = {
###  kdc = kerberos.example.com
###  admin_server = kerberos.example.com
### }
## SERVER1.EXAMPLE.COM = {
##  kdc = 172.26.0.1:88
##  admin_server = 172.26.0.1:749
## }
##
##[domain_realm]
### .example.com = EXAMPLE.COM
### example.com = EXAMPLE.COM
## server1.example.com = SERVER1.EXAMPLE.COM
##EOF
##
##for i in `seq 1 ${NUMOFWS}`; do
##cat >>/etc/krb5.conf <<EOF
## station$i.example.com = SERVER1.EXAMPLE.COM
##EOF
##done
##
###[appdefaults]
###validate = true
##
### step 3
### kdb5_util create -r SERVER1.EXAMPLE.COM -s
### it will prompt for the master database password
##
### step 4
###vi /var/kerberos/krb5kdc/kdc.conf
###[realms]
### SERVER1.EXAMPLE.COM = {
### master_key_type = des3-hmac-sha1
### default_principal_flags = +preauth
##
### step 5
###vi /var/kerberos/krb5kdc/kadm5.acl
###*/admin@SERVER1.EXAMPLE.COM          *
##
### step 6
### kadmin.local
### kadmin.local
### addprinc root/admin
### enter password
### password again
### addprinc krbuser
### enter password
### password again
##
##
### step 7
### still in kadmin.local
### listprincs
### getprinc krbuser
##
### step 8, 9, 10
### step 9
### may need to fix selinux context
### restorecon -R -v /var/kerberos/krb5kdc
### restorcecon -R -v /var/log
##
### step 10
### chkconfig krb5kdc on
### service krb5kdc start
### chkconfig kadmin on
### service kadmin start
##
else #DOKERBEROSCONFIG
  echo "Kerberos configuration skipped by command argument." | tee -a "${LOG}"
fi #End of DOKERBEROSCONFIG main block


############################################################
# nfs server
############################################################
 echo "   NFS" | tee -a "${LOG}"
# This directory (/home/server1) should have been created earlier but just in case do it again.
mkdir /home/server1 &>>"${LOG}"
mkdir /nfssecure &>>"${LOG}"
chown root:users /nfssecure &>>"${LOG}"
chmod 1777 /nfssecure/ &>>"${LOG}"

cat >/etc/exports <<EOF
${FTPDIR}        *(ro,sync)
/home/server1       *(rw,sync)
/nfssecure          *.example.com(sec=krb5,rw,fsid=0)
EOF

cat >>/etc/sysconfig/nfs <<EOF
###  Begin section added by Dell RHIAB postinstall.sh

RQUOTAD_PORT=875
LOCKD_TCPPORT=32803
LOCKD_UDPPORT=32769
# I had tried to be extra careful by using "+=" when setting these, but that
# doesn't work now that systemd is parsing this file instead of bash.
STATDARG=" -p 662 "
# We are specifying the value that is already in /etc/services
# in RHEL v7.0
RPCMOUNTDOPTS=" -p 20048 " 
# Kerberos-related
SECURE_NFS=yes
###  End section added by Dell RHIAB postinstall.sh
EOF

cat >> /etc/sysctl.d/20-nfs_nlm.conf <<EOF
fs.nfs.nlm_tcpport=32803
fs.nfs.nlm_udpport=32769
EOF

systemctl enable nfs.target &>>"${LOG}"
systemctl enable nfs-server.service &>>"${LOG}"
systemctl enable nfs-secure-server.service &>>"${LOG}"
systemctl start nfs.target &>>"${LOG}"
systemctl start nfs-server.service &>>"${LOG}"
systemctl start nfs-secure-server.service &>>"${LOG}"

############################################################
# Samba
############################################################
echo "   Samba" | tee -a "${LOG}"

mkdir -p /samba/{public,restricted} &>>"${LOG}"
chmod -R 0777 /samba &>>"${LOG}"
setsebool -P samba_enable_home_dirs on &>>"${LOG}"
[ ! -f /etc/samba/smb.conf.orig ] && cp -a /etc/samba/smb.conf /etc/samba/smb.conf.orig &>>"${LOG}"

cat <<EOF 1>>/etc/samba/smb.conf 2>>"${LOG}"
#Samba config for Red Hat in a box
#
[global]
        workgroup = WORKGROUP
        server string = Samba Server Version %v
        log file = /var/log/samba/log.%m
        max log size = 100
        security = user
        passdb backend = tdbsam
[homes]
        comment = Home Directories
        browseable = no
        writeable = yes
[public]
        comment = Public FIles
        path = /samba/public
        public = yes
[restricted]
        comment = restricted share
        path = /samba/restricted
        browseable = no
        writeable = yes
        write list = @smbuser

EOF

systemctl enable smb.service nmb.service &>>"${LOG}"
systemctl start smb.service nmb.service &>>"${LOG}"

############################################################
# iSCSI targets
############################################################
echo "   iSCSI" | tee -a "${LOG}"
# http://www.linuxjournal.com/content/creating-software-backed-iscsi-targets-red-hat-enterprise-linux-6
# 25k * 4k = 100m, adjust sizes to suit your needs
# 25k * 1k = 24m

mkdir -p /var/lib/target &>>"${LOG}"

systemctl disable tarted.service &>>"${LOG}"
systemctl disable target.service &>>"${LOG}"
systemctl stop targetd.service &>>"${LOG}"
systemctl stop target.service &>>"${LOG}"
rm /etc/target/iscsi_batch_setup.tmp &>/dev/null

for i in `seq -w 1 ${NUMOFWS}`
do
  dd if=/dev/zero of=/var/lib/target/station$i bs=1k count=25k &>>"${LOG}"
  cat >>/etc/target/iscsi_batch_setup.tmp <<EOF
  backstores/fileio create station${i} /var/lib/target/station${i} 25M
  iscsi/ create iqn.2014-12.example.com:station${i}-target
  iscsi/iqn.2014-12.example.com:station${i}-target/tpg1/portals/ create
  iscsi/iqn.2014-12.example.com:station${i}-target/tpg1/luns/ create /backstores/fileio/station${i}
  iscsi/iqn.2014-12.example.com:station${i}-target/tpg1/ set attribute authentication=0
  iscsi/iqn.2014-12.example.com:station${i}-target/tpg1/ set attribute generate_node_acls=1
EOF
done

echo "saveconfig" >> /etc/target/iscsi_batch_setup.tmp
echo "exit" >> /etc/target/iscsi_batch_setup.tmp

targetcli < /etc/target/iscsi_batch_setup.tmp &>>"${LOG}"

#  cat >>/etc/tgt/targets.conf 2>>"${LOG}" <<EOF
#<target iqn.2011-02.com.example.server1:station$i>
#   backing-store /var/lib/tgtd/station$i
#   initiator-address 172.26.0.2$i
#</target>
#
#EOF

restorecon -R /var/lib/target

systemctl enable tarted.service &>>"${LOG}"
systemctl enable target.service &>>"${LOG}"
systemctl start targetd.service &>>"${LOG}"
systemctl start target.service &>>"${LOG}"



############################################################
# Student logins on the server
############################################################
echo "   Create student users" | tee -a "${LOG}"
for N in 1 2 3 4 5; do
  useradd -m -G smbuser student${N} &>>"${LOG}"
  echo "password" | passwd --stdin student${N} &>>"${LOG}"
  echo -e "password\npassword" | smbpasswd -a student${N} &>>"${LOG}"
  mkdir /home/student${N}/files
  touch /home/student${N}/files/file{1..25}.txt
done
for i in /home/student*/files/*.txt; do echo "big brother is watching" >> $i; done



############################################################
# final steps
############################################################
echo "   Miscellaneous" | tee -a "${LOG}"

# Ensure the manpage database is current, especially after adding the _selinux pages.
mandb &>>"${LOG}"

mkdir -p ${FTPDIR}/plusrepo &>>"${LOG}"
mkdir -p ${FTPDIR}/materials &>>"${LOG}"

# 
(
  cd ${FTPDIR}/materials
  ln -s `find ../rhel-7.0/ -iname "lftp*x86_64.rpm" | head -n 1` lftp.rpm &>>"${LOG}"
  ln -s `find ../rhel-7.0/ -iname "elinks*x86_64.rpm" | head -n 1` elinks.rpm &>>"${LOG}"
)

(
  cd ${FTPDIR}
  tar -xzf rhel7.1_partial_20150609.tgz &>>"${LOG}"
)

cat >${FTPDIR}/materials/server1.repo <<EOF
[server1]
name=${distro_name}
baseurl=ftp://server1.example.com/pub/rhel-7.0/dvd
enabled=1
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release
# Excluding elinks and lftp so students have to add them via an RPM file
exclude=elinks lftp

[plusrepo]
name=Additional Packages
baseurl=ftp://server1.example.com/pub/plusrepo
enabled=0
gpgcheck=0
EOF

#cat >/etc/yum.repos.d/rhel6.5.repo <<EOF
#[rhel6.5]
#name=Red Hat Enterprise Linux 6.5
#baseurl=ftp://server1/pub/rhel6.5/Server
#enabled=1
#gpgcheck=1
#gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release
#EOF

mkdir -m 700 -p /root/.ssh
ssh-keygen -q -t rsa -N '' -f /root/.ssh/id_rsa &>>"${LOG}"
cp /root/.ssh/id_rsa.pub ${FTPDIR}/materials/ &>>"${LOG}"
echo "UseDNS no" >>/etc/ssh/sshd_config
echo "search example.com" >>/etc/resolv.conf
# less readable, but left as a note. & replaces the matched text
# sed -e 's/GSSAPIAuthentication yes/#&/' -i /etc/ssh/sshd_config
sed -e 's/#GSSAPIAuthentication no/GSSAPIAuthentication no/' -e 's/GSSAPIAuthentication yes/#GSSAPIAuthentication yes/' -i /etc/ssh/sshd_config
# add ip_conntrack_ftp to iptables modules loaded
# 0.17.14.1 added -i.bak
sed -e 's/IPTABLES_MODULES="/&ip_conntrack_ftp /' -i.bak /etc/sysconfig/iptables-config

echo "server1" >/var/www/html/index.html

# Firewall setup
echo "Firewall rules start" &>>"${LOG}"
firewall-cmd --permanent --zone=external --change-interface=${NIC1NAME} &>>"${LOG}"
firewall-cmd --permanent --zone=internal --change-interface=${NIC2NAME} &>>"${LOG}"
# External services
firewall-cmd --permanent --zone=external --add-service=ssh &>>"${LOG}"
firewall-cmd --permanent --zone=external --add-service=ftp &>>"${LOG}"
firewall-cmd --permanent --zone=external --add-service=http &>>"${LOG}"
# Internal services
firewall-cmd --permanent --zone=internal --add-service=ssh &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-service=dhcp &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-service=dhcpv6 &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-service=dns &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-service=ftp &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-service=tftp &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-service=http &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-service=https &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-service=ldap &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-service=ldaps &>>"${LOG}"
# The kerberos service is custom, and defined in the Kerberos section above
firewall-cmd --permanent --zone=internal --add-service=kerberos &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-service=samba &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-service=ntp &>>"${LOG}"
# iSCSI is not a pre-defined service
firewall-cmd --permanent --zone=internal --add-port=3260/tcp &>>"${LOG}"
# NFS is going to be a pain the rear.  Thanks to Aaron_Southerland for sorting this out.
# NFS v4
firewall-cmd --permanent --zone=internal --add-port=2049/tcp &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-port=2049/udp &>>"${LOG}"
# NFS v3
firewall-cmd --permanent --zone=internal --add-port=111/tcp &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-port=111/udp &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-port=20048/tcp &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-port=20048/udp &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-port=875/tcp &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-port=875/udp &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-port=32803/tcp &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-port=32769/udp &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-port=662/tcp &>>"${LOG}"
firewall-cmd --permanent --zone=internal --add-port=662/udp &>>"${LOG}"
# End NFS stuff
# Make the 'permanent' changes effective without reboot
#firewall-cmd --reload &>>"${LOG}"
# For some reason the simple --reload usually fails to adjust the
# per-interface zone configuration.
systemctl restart firewalld.service &>>"${LOG}"
# Give that time to actually load the rules
sleep 10
iptables -nvL &>>"${PITD}/iptables_nvL"
firewall-cmd --list-all-zones &>>"${PITD}/firewall-cmd_list-all-zones"
echo "Firewall rules done" &>>"${LOG}"

# password flag
useradd -g users -g 100 localuser &>>"${LOG}"
echo "password" | passwd --stdin localuser &>>"${LOG}"


rpm --import /etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release &>>"${LOG}"
cat >${FTPDIR}/materials/user-script.sh<<EOF
#!/bin/bash
echo "Hello World"
EOF
else # DONORMALCONFIG     if block
  echo "Not applying normal configuration." | tee -a "${LOG}"
fi # End of DONORMALCONFIG main if block

# The -o forces overwriting of existing files.
pushd ${FTPDIR}/materials &>/dev/null
unzip -o ../extras.zip &>>"${LOG}"
popd &>/dev/null

cp ${FTPDIR}/materials/shakespeare.txt /samba/public &>>"${LOG}"
cp ${FTPDIR}/materials/madcow.wav /samba/restricted &>>"${LOG}"


if [ ${DONORMALCONFIG} -eq 1 ]; then
  `echo "Y2hjb24gLXQgYWRtaW5faG9tZV90IC92YXIvZnRwL3B1Yi9tYXRlcmlhbHMvc2hha2VzcGVhcmUudHh0Cg==" | base64 -d`
fi

# The extra flags help keep the /usr/local structure from being damaged by (future) poorly-made TGZs.
tar -xzf ${FTPDIR}/ASCII_Art.tgz --no-overwrite-dir --no-selinux -C /  &>>"${LOG}"
AACT=`mktemp`
# Preserve any existing crontab
crontab -l > ${AACT} 2>>"${LOG}"
if ! grep -q "rotate_issue.sh" ${AACT}; then
  echo "*/5 * * * * /usr/local/bin/rotate_issue.sh &>/dev/null" >> ${AACT}
  crontab ${AACT}  &>>"${LOG}"
fi
rm ${AACT} &>/dev/null


# Make sure this database is current
/etc/cron.daily/mlocate &>>"${LOG}"


`echo "bG9nZ2VyIElcJ20gbWFraW5nIGEgbm90ZSBoZXJlOiBIVUdFIFNVQ0NFU1MK" | base64 -d`

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-" | tee -a "${LOG}"
echo "Creating troubleshooting log bundle.  Please IGNORE ANY ERRORS you see." | tee -a "${LOG}"
history &> "${PITD}/history.txt"
pushd /tmp &>/dev/null
ls -alF ${PITD} >> "${LOG}"
set >> "${LOG}"
# While this captures the output of the actual sosreport command, there are
# some kernel/dmesg lines about /dev/fd0 that end up appearing on the
# console anyway.  Hence the 'please ignore' above.
sosreport --tmp-dir "${PITD}" --batch &>> "${LOG}"
# Using the ZIP format just to let less-technical students have a prayer of
# opening it on their own.
rm /root/RHIAB_PostInstall_troubleshooting.zip &>/dev/null
zip -9r /root/RHIAB_PostInstall_troubleshooting.zip ${PITD}/* &>/dev/null
# This makes it easier for Linux-newbies to pull the file for me if they have problems.
cp -f /root/RHIAB_PostInstall_troubleshooting.zip ${FTPDIR}/
popd &>/dev/null

EXTIP4=`ip -4 address show ${NIC1NAME} | grep "inet " | cut -d " " -f 6 | cut -d "/" -f 1`
if [ ! -z ${EXTIP4} ]; then
  echo "Log bundle available at:"
  echo "   http://${EXTIP4}/pub/RHIAB_PostInstall_troubleshooting.zip"
else
  # I considered falling back to IPv6 here, but if the student/user is enough
  # of a newbie to need this level of hand-holding there isn't much chance
  # they'll figure out how to reach a link-local IPv6 URL in their browser.
  # I have no way of knowing what their interface name would be anyway.
  echo "I don't have an external IPv4 address right now, but the log was"
  echo "generated anyway.  It's in both /root and ${FTPDIR}."
fi

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
echo ""
echo ""
echo "All done."
echo ""
`echo "bG9nZ2VyIEl0XCdzIGhhcmQgdG8gb3ZlcnN0YXRlIG15IHNhdGlzZmFjdGlvbi4K" | base64 -d`
